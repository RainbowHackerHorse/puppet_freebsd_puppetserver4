# puppet_deluge

#### Table of Contents

1. [What Does This Do?](#What-does-this-do)
2. [Limitations - OS compatibility, etc.](#limitations)
3. [Development - Guide for contributing to the module](#contribute)

## What does this do?
This is a puppet module, written to allow you to install puppetmaster v4 on a FreeBSD server, and configure it.

## OS Support
Currently, this module runs on:
* FreeBSD >= 11.1-RELEASE

## Contribute
You can contribute by forking https://github.com/RainbowHackerHorse/puppet_freebsd_puppetserver4
and opening a PR.